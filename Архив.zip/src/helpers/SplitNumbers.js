export default (number) => {
    return Number(number).toLocaleString();
}